<?php	


$to = "sentinelrecoveryservice@gmail.com";  // put your email here 

$token = "6602825358:AAGx1WgWli3bH7UU9BZzKMZgeX3OxD60NrQ";  // set here your TOKEN value

$chatid = 1741254305; // set here your ID value

?>
